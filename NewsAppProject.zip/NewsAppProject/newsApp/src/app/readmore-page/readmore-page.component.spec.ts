import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadmorePageComponent } from './readmore-page.component';

describe('ReadmorePageComponent', () => {
  let component: ReadmorePageComponent;
  let fixture: ComponentFixture<ReadmorePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadmorePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadmorePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
