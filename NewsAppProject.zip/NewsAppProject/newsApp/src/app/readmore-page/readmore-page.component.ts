import { Component, OnInit } from '@angular/core';
import { NewsService } from '../services/news.service';

@Component({
  selector: 'app-readmore-page',
  templateUrl: './readmore-page.component.html',
  styleUrls: ['./readmore-page.component.scss']
})
export class ReadmorePageComponent implements OnInit {
  articles;
  constructor(private newsService: NewsService) { }

  ngOnInit() {
    this.articles = this.newsService.currentNewsArticle;
    console.log(this.newsService.currentNewsArticle);
  }

}
