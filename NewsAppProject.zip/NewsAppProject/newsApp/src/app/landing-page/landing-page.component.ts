import { Component, OnInit } from '@angular/core';
import { NewsService } from '../services/news.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { trigger, style, animate, transition, group, stagger, query, animateChild } from '@angular/animations';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
  animations: [
    trigger('ngIfAnimation', [
      transition('void => *', [
        query(':self', style({ opacity: 0, transform: 'translateY(-20%)' }), { optional: false }),
        query(':self', stagger('0ms', [
          animate('1s ease-out', style({ opacity: 1, transform: 'translateY(0)' }),
          )]), { optional: false }),
      ]),
    ])
  ]
})
export class LandingPageComponent implements OnInit {
  articlesData: any;
  filteredVenues: any;
  searchTerm: string;
  p = 1;
  constructor(private newsService: NewsService, private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.spinner.show().then(() => {
      this.showSpinner();
      this.newsService.getNewsData('top-headlines?country=us&category=business')
      .subscribe(data => {
        console.log('shows');
        this.articlesData = data;
        this.spinner.hide();
      });
    });
  }


  showSpinner() {
    this.spinner.show();
  }


  filterDate(queryDate: any) {
    this.filteredVenues = (queryDate) ?
    this.articlesData.filter(v => new Date(v.datecreated) === queryDate) :
    this.articlesData;
  }

  goToCurrentNews(articles) {
    // tslint:disable-next-line:no-unused-expression
    this.newsService.currentNewsArticle = articles;
    this.router.navigate(['/readmore-page']);
  }
}




